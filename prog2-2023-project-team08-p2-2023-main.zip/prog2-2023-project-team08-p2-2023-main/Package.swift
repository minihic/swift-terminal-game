// swift-tools-version:5.5
import PackageDescription

let package = Package(
	name: "prog2-2023-project",
	products: [
		.executable(name: "prog2-2023-project", targets: ["prog2-2023-project"]),
	],
	dependencies: [],
	targets: [
		.executableTarget(name: "prog2-2023-project", dependencies: [])
	]
)
